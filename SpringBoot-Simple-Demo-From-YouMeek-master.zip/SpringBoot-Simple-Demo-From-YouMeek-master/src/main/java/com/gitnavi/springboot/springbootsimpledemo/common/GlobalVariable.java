package com.gitnavi.springboot.springbootsimpledemo.common;


public class GlobalVariable {


	public static final int SERIOUS_PERFORMANCE_PROBLEMS_TIME_THRESHOLD = 10;
	public static final int GENERAL_PERFORMANCE_PROBLEMS_TIME_THRESHOLD = 5;
	public static final int NEED_OPTIMIZE_TIME_THRESHOLD = 3;

}
