
DELETE FROM sys_user;

insert into sys_user(id,login_name,email,delete_enum,create_date,lock_version) values 
('374933329427959801','judasn1','judas.n1@qq.com',0,'2016-06-20 11:49:53',3),
('374933329427959802','judasn2','judas.n2@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959803','judasn3','judas.n3@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959804','judasn4','judas.n4@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959805','judasn5','judas.n5@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959806','judasn6','judas.n6@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959807','judasn7','judas.n7@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959808','judasn8','judas.n8@qq.com',0,'2017-01-05 14:59:05',2),
('374933329427959809','judasn9','judas.n9@qq.com',0,'2017-01-05 14:59:05',2);

